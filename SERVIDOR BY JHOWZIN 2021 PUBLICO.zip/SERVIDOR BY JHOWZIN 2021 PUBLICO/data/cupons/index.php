<?php
defined( 'WR_INC' ) ||
    die( '<script>
        window.location.href=\'/nao-encontrado.html\';
    </script>');


?>